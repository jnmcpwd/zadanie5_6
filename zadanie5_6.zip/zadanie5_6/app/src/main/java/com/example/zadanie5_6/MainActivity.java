package com.example.zadanie5_6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Patterns;


public class MainActivity extends AppCompatActivity {

    private int likes = 0;
    private TextView likesTextView;
    private EditText editTextEmail, editTextPassword, editTextConfirmPassword;
    private TextView textFeedback;
    private Button buttonSubmit;
    private Button buttonUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        likesTextView = findViewById(R.id.likesTextView);
        Button likeButton = findViewById(R.id.likeButton);
        Button unlikeButton = findViewById(R.id.unlikeButton);
        editTextEmail = findViewById(R.id.inputEmail);
        editTextPassword = findViewById(R.id.inputPassword);
        editTextConfirmPassword = findViewById(R.id.inputConfirmPassword);
        textFeedback = findViewById(R.id.textFeedback);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonUser = findViewById(R.id.buttonUser);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String emailInput = editTextEmail.getText().toString().trim();
                String passwordInput = editTextPassword.getText().toString().trim();
                String confirmPasswordInput = editTextConfirmPassword.getText().toString().trim();


                if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
                    textFeedback.setText("Podany adres e-mail jest nieprawidłowy");
                } else if (passwordInput.isEmpty()) {
                    textFeedback.setText("Nie wpisano hasła");
                } else if (confirmPasswordInput.isEmpty()) {
                    textFeedback.setText("Nie wpisałeś ponownie hasła");
                }else if (!passwordInput.equals(confirmPasswordInput)) {
                    textFeedback.setText("Hasła są różne");
                }else {
                    textFeedback.setText("Zarejestrowano:" +emailInput);
                }
            }
        });

        buttonUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailInput = editTextEmail.getText().toString().trim();
                textFeedback.setText("Witaj " + emailInput);
            }
        });

        updateLikesText();

        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                likes++;
                updateLikesText();
            }
        });

        unlikeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (likes > 0) {
                    likes--;
                }
                updateLikesText();
            }
        });
    }
    private void updateLikesText() {
        likesTextView.setText(likes + " polubień");
    }

}
